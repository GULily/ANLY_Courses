top1m.filter(lambda line: ".com" in line).count()
