#!/usr/bin/env python35
#
# Parse an MTR file in text mode and turn it into a tinydata file.
#
import os, datetime, re
import sys
if sys.version < "3.4":
    raise RuntimeError("requires Python 3.4 or above")


# "Return an ISO8601-formatted timestamp from an input line"
def parse_timestamp(line):
    assert line.startswith("Start:")
    ts = datetime.datetime.strptime(line[7:], "%a %b %d %H:%M:%S %Y")  # Wed Dec 28 23:37:02 2016
    ts = ts.isoformat()
    return ts


# mtr_line_exp = re.compile("(\d+)\..*\s(\?+|\d+\.\d+\.\d+\.\d+|[a-z]+.*)\s+(\d+)\.0.*\s+\d\s+(\d+\.\d|\d+\.)\s+(\d+\.\d|\d+\.)\s+(\d+\.\d|\d+\.)\s+(\d+\.\d|\d+\.)\s+(\d+\.\d)")   # put something here
mtr_line_exp = re.compile("(\d)\S+\s(\S+)\s+(\d+)\S+\s+\d\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)")   # put something here


class MtrLine:
    def __init__(self, ts, line):
        # Parse line and fill these in.
        # ts is the timestamp that we previously found
        line = line.strip()
        m = mtr_line_exp.search(line)
        self.timestamp = ts
        self.hop_number = m.group(1)
        if re.search('\d+\.\d+\.\d+\.\d+', m.group(2)):
            self.ipaddr = m.group(2)
        else:
            self.ipaddr = ''
        if re.search('[a-z]+', m.group(2)):
            self.hostname = m.group(2).strip()
        else:
            self.hostname = ''
        self.pct_loss = m.group(3)
        self.time = m.group(4)


def fix_mtr(infile,outfile):
    count = 0
    current_timestamp = None
    for line in infile:
        line = line.replace('\x00','').strip()     # remove leading and trailing white space
        if line.startswith('Start:'):
            # Beginning of a new record...
            # print("Replace this print statement with new code. Probably need to set a variable with the time...")
            current_timestamp = parse_timestamp(line)
            continue
        if line.startswith('HOST:'):
            # This can be ignored, since we always start at the same location
            continue

        # try:
        m = MtrLine(current_timestamp, line)
        # except:
        #     exception += 1
        #     print(exception)
        #     pass

        if m.hostname:
            # print(m.hostname)
            f = open("lookup.txt", "r")
            for line in f:
                line = line.strip().split(";")
                for string in line:
                    # print(string)
                    if string.startswith(m.hostname):
                        # print(string)
                        m.hostname = string
                        if string.find('('):
                            i = string.find('(')
                            m.hostname = string[:i]
                            m.ipaddr = string[i + 1:-1]
                            # print(m.hostname)
                            # print(m.ipaddr)
                        break
                else:
                    continue
                break

        if m.timestamp:
            # print("Regular expression matched. Replace this with code...")
            outfile.write(m.timestamp + "," + m.hop_number + "," + m.ipaddr + "," +
                          m.hostname + "," + m.pct_loss + "," + m.time + '\n')
            count += 1
    return count


if __name__=="__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--infile",help="input file",default="mtr.www.cnn.com.txt")
    parser.add_argument("--outfile",help="output file",default="tidy.txt")
    args = parser.parse_args()

    # if os.path.exists(args.outfile):
    #     raise RuntimeError(args.outfile + " already exists. Please delete it.")

    print("{} -> {}".format(args.infile,args.outfile))

    count = fix_mtr(open(args.infile,"rU"), open(args.outfile,"w+"))
    print("{} records converted".format(count))
